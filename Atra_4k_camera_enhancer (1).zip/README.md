# Atra 4K Camera Enhancer

A simple Flutter app that enhances your pictures to a clearer, brighter 4K-like quality.

## ✨ Features
- Capture photo from camera or choose from gallery  
- Apply brightness, contrast, and sharpness improvements  
- View original and enhanced images  
- Save the enhanced image  

## 🚀 How to Run
```bash
flutter pub get
flutter run
```

To build APK:
```bash
flutter build apk --release
```

APK output:
```
build/app/outputs/flutter-apk/app-release.apk
```

---

👤 Created by **Mhlengi Duma (mhlengid091-hub)**
