import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'dart:io';
import 'package:image/image.dart' as img;

void main() {
  runApp(Atra4KApp());
}

class Atra4KApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Atra 4K Camera Enhancer',
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      home: EnhanceScreen(),
      debugShowCheckedModeBanner: false,
    );
  }
}

class EnhanceScreen extends StatefulWidget {
  @override
  _EnhanceScreenState createState() => _EnhanceScreenState();
}

class _EnhanceScreenState extends State<EnhanceScreen> {
  File? _image;
  File? _enhancedImage;
  final picker = ImagePicker();

  Future<void> _getImage(ImageSource source) async {
    final pickedFile = await picker.pickImage(source: source);
    if (pickedFile != null) {
      setState(() {
        _image = File(pickedFile.path);
      });
      _enhanceImage(_image!);
    }
  }

  void _enhanceImage(File original) async {
    final imageBytes = await original.readAsBytes();
    img.Image? originalImg = img.decodeImage(imageBytes);
    if (originalImg != null) {
      // Basic "enhancement" (contrast + brightness)
      img.Image enhanced = img.adjustColor(originalImg, contrast: 1.2, brightness: 0.1, saturation: 1.1);
      final enhancedPath = original.path.replaceAll('.jpg', '_enhanced.jpg');
      final enhancedFile = File(enhancedPath)
        ..writeAsBytesSync(img.encodeJpg(enhanced, quality: 95));
      setState(() {
        _enhancedImage = enhancedFile;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Atra 4K Camera Enhancer')),
      body: Center(
        child: SingleChildScrollView(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              if (_image == null)
                Text('No image selected.', style: TextStyle(fontSize: 18))
              else
                Column(
                  children: [
                    Image.file(_image!, height: 200),
                    SizedBox(height: 20),
                    if (_enhancedImage != null) ...[
                      Text('Enhanced Image:', style: TextStyle(fontSize: 18)),
                      Image.file(_enhancedImage!, height: 200),
                    ]
                  ],
                ),
              SizedBox(height: 30),
              ElevatedButton.icon(
                onPressed: () => _getImage(ImageSource.camera),
                icon: Icon(Icons.camera_alt),
                label: Text('Capture Photo'),
              ),
              SizedBox(height: 10),
              ElevatedButton.icon(
                onPressed: () => _getImage(ImageSource.gallery),
                icon: Icon(Icons.photo_library),
                label: Text('Select from Gallery'),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
